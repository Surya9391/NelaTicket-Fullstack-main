import React from "react";

//axios
import axios from "axios";

//HOC
import DefaultHOC from "./HOC/Default.HOC";
import MovieHOC from "./HOC/Movie.HOC";

//Component
import HomePage from "./pages/Home.page";
import Movie from "./pages/Movie.page";
import Plays from "./pages/Plays.page";
import Shows from "./pages/Shows.page";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

//axios default settings 
axios.defaults.baseURL ="https://api.themoviedb.org/3";
axios.defaults.params = {};
axios.defaults.params["api_key"] = process.env.REACT_APP_API_KEY;

function App() {
  return (
    <>
    <DefaultHOC path="/" exact Component={HomePage} />
    <MovieHOC path="/movie/:id" exact Component={Movie} />
    <MovieHOC path="/plays" exact Component={Plays} />
    <MovieHOC path="/plays/:id" exact Component={Shows} />
    </>
  );
}

export default App;
