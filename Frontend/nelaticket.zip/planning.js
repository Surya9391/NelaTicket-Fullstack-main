//Book My Show Planning

//We basically reusable carousel
//-> Hero Carousel
//-> common carousel
//-> Cast Carousel(small carousel)

//Pages
//-> Home page
//-> Movie Page
//-> Categories Page
//-> Razorpay payment gateway

//Plan how we are building it
//-> Layouts
//-> Routes
//-> Pages
//-> Components


