import React from "react";

const Temp = () => {
  return (
    <h1>This is a Temp Component</h1>
  )
}

export default Temp;
